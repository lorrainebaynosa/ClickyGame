// REVIEW OF CONCEPTS:
// 1. every conditional returns true or false (reminder 1 resolves to true)
// These are all falsy in conditional statements
// false
// 0 (zero)
// ‘’ or “” (empty string)
// null
// undefined
// NaN

// Internally, JavaScript sets a value to one of six primitive data types:
// https://www.sitepoint.com/javascript-truthy-falsy/ 
// Undefined (a variable with no defined value)
// Null (a single null value)
// Boolean (true or false)
// Number (this includes Infinity and NaN – not a number!)
// String (textual data)
// Symbol (a unique and immutable primitive new to ES6/2015)
// Everything else is an Object — including arrays.

// TRUTHY vs FALSY values:
// As well as a type, each value also has an inherent boolean value, generally known as either truthy or falsy. Some of the rules are a little bizarre so understanding the concepts and effect on comparison helps when debugging JavaScript applications.

// The following values are always falsy:

// false
// 0 (zero)
// '' or "" (empty string)
// null
// undefined
// NaN
// Everything else is truthy. That includes:
// '0' (a string containing a single zero)
// 'false' (a string containing the text “false”)
// [] (an empty array)
// {} (an empty object)
// function(){} (an “empty” function)


// 1.
console.log(true || false);
// returns true
console.log(true && false);
// returns false
console.log(0 && "lol");
// returns false 
console.log(false || "IDK MY BFF JILL");
// returns true

// 2.
console.log("" && [].length);
// false
console.log("" || [].length);
// false
console.log("" || [].length || 0);
// false; empty array.length === falsy since equal to zero


// 3. TERNARY STATEMENT
const likesVeggies = false;
const meal = likesVeggies ? "Vegetable Stir Fry" : "Cheeseburger";
console.log(meal);
// REVIEW OF CONCEPTS: 
// RETURNS Cheeseburger because likesVegges = false; assigning the result of the conditional statement/expression and assigning it to the constant (EXPRESSION RESOLVES 1st and then the result/resolution is assigned to the constant); use ternaries only if doing a simple ternary
// 

// ROC: EQUIVALENT; REMINDER: all conditionals resolve to true or false
// if (likesVeggies) {
//     var meal = "Vegetable Stir Fry";
// } else { 
//     var meal = "Cheeseburger"
// }

// 4.
const feelingWell = false;
const goingOutTonight = feelingWell ? "Of course I'm going!" : "Not tonight, I'm not feeling well.";
console.log(goingOutTonight);
// Returns "Not tonight, I'm not feeling well."; (EXPRESSION RESOLVES 1st and then the result/resolution is assigned to the constant: since feeling well is false, result "Not tonight..." is assigned to constant goingOutTonight.

// REVIEW OF CONCEPTS (test in node.js): ensure in same directory as index.js in terminal/bash: 
// node index.js
// RETURNS: 
// true
// false
// 0
// IDK MY BFF JILL

// 0
// 0
// Cheeseburger
// Not tonight, I'm not feeling well.

