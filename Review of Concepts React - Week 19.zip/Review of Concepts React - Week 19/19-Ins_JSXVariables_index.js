import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App />, document.getElementById("root"));

// RENDERING AN ELEMENT IN THE DOM
// https://reactjs.org/docs/rendering-elements.html

// {/* <div id="root"></div>
// We call this a “root” DOM node because everything inside it will be managed by React DOM. Applications built with just React usually have a single root DOM node. If you are integrating React into an existing app, you may have as many isolated root DOM nodes as you like.
// To render a React element into a root DOM node, pass both to ReactDOM.render(): 
// const element = <h1>Hello, world</h1>;
// ReactDOM.render(element, document.getElementById('root'));

// ReactDOM: library separate from REact with methods for working w/DOM