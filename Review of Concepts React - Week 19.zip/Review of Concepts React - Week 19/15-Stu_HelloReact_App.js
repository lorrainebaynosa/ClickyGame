import React from "react";
import HelloReact from "./components/HelloReact";

function App() {
  return <HelloReact />;
}

export default App;

// REVIEW OF CONCEPTS: 
// 1. import React from "react": Whenever we use JSX inside of our JavaScript, we need to import the React library (see React.createElement(HelloReact, null); Because the plain JavaScript code uses this method, we get the 'React' must be in scope when using JSX error when compiling if we don't import React.
// 2. When Babel translates `App` component's JSX code to plain old JavaScript, it looks like this:
  // * ```js
  // var App = function App() {
  //   return React.createElement(HelloReact, null);
  // };
  // ```
// 3. Purpose of App.js: 
// a. defines another component named `App`. It's common to have multiple components that fit together inside of a React application. Typically compose all of the top level components inside of our `App` component; 
// b. the `App` function or component just returns our `HelloReact` component.
// what's going on in this file? Try to answer the following questions:
//   1. What does the `App` function return? <HelloReact /> component from HelloReact.js: <p>Hello World!</p>
//   2. Why do we import the React library? We aren't using the React keyword anywhere. Is it possible to remove this and still have our code work? Can't remove it. Need React library
