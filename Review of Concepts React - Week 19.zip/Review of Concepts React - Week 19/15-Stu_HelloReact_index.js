import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App />, document.getElementById("root"));

// REVIEW OF CONCEPTS: https://reactjs.org/docs/hello-world.html
// 1. React is a JavaScript library. Important points about JavaScript: 
// We use the class keyword to define JavaScript classes. There are two things worth remembering about them. Firstly, unlike with objects, you don't need to put commas between class method definitions. Secondly, unlike many other languages with classes, in JavaScript the value of this in a method depends on how it is called.
// We sometimes use => to define "arrow functions". They're like regular functions, but shorter. For example, x => x * 2 is roughly equivalent to function(x) { return x * 2; }. Importantly, arrow functions don't have their own this value so they're handy when you want to preserve the this value from an outer method definition.
// 2. smallest react example: line 5, displays <p>Hello World!</p> on the page.
// use `ReactDOM.render` to render single component or tree of components to DOM. `App` is the root of our component tree (it renders all of our other components inside).
// RENDERING AN ELEMENT IN THE DOM
// https://reactjs.org/docs/rendering-elements.html
//  {/* <div id="root"></div>
//  We call this a “root” DOM node because everything inside it will be managed by React DOM. Applications built with just React usually have a single root DOM node. If you are integrating React into an existing app, you may have as many isolated root DOM nodes as you like.
// To render a React element into a root DOM node, pass both to ReactDOM.render(): 
// const element = <h1>Hello, world</h1>;
// ReactDOM.render(element, document.getElementById('root'));

// we're importing the `ReactDOM` library. Try to answer the following questions:
//   * Do you remember what the purpose of `ReactDOM.render` is? What is it doing? RENDERING App component to div
//   * Is this where our components are rendered to the DOM?
//   * Instead of splitting our files up into `App`, `components/HelloReact` and `index`, is it possible to just write our entire Hello World app in the `index.js` file?

// TO TEST THE CODE: 
// cd reactpractice
// run npm start
// RETURNS: Hello World!
