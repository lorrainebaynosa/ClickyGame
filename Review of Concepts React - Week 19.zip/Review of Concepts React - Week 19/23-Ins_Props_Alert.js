import React from "react";

function Alert(props) {
  console.log(props);

  return (
    <div className={`alert alert-${props.type || "success"}`} role="alert">
      {props.children}
    </div>
  );
}

export default Alert;


// ROC: use template literals to made code easier to read: `alert alert-${props.type || "success"}`. if props.type exist (Alert type="danger"), then it reads alert alert-danger ELSE it reads alert alert-success (Alert W/O type)
// {props.children}: 
  // 1. Invalid user id or password: This is a child of Alert component because it's nested within Alert (parent)
  // 2. The text 
// type="danger" is similar to a data attribute (red); type="success" is green
// props ARE all objects
// VERIFY ON CONSOLE in dev tools: will see type and children
// here we pass in component Alert into component App