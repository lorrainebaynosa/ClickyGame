class Vehicle {
  constructor(topSpeed = 50) {
    this.speed = 0;
    this.topSpeed = topSpeed;
  }

  accelerate(increase = 10) {
    console.log("Accelerating!");
    this.speed = Math.min(this.speed + increase, this.topSpeed);
    this.logSpeed();
    // ROC: this.logSpeed, where this will check if property exists in Car 1st (Ferrari object instance) and if not, will then check if property exists in parent, Vehicle.js
  }

  logSpeed() {
    console.log(`Current Speed: ${this.speed}`);
  }

  brake() {
    console.log("Hitting the brakes!");
    this.speed = 0;
    this.logSpeed();
  }
}

// ROC: when running/testing Car.js, comment out lines 25 and on since in Vehicle.js since we're requiring this file in Car.js and so will run all the code if not commmented out
var vehicle = new Vehicle();
// ROC: if leave as is, this is equivalent to var vehicle = new Vehicle(50);

vehicle.logSpeed();

console.log(`Top speed is ${vehicle.topSpeed}`);
// ROC: object literal use back tick (top left hand button under tilde)

vehicle.accelerate();

vehicle.accelerate(30);

// --- Pre ES6 version

// function Vehicle(topSpeed) {
//   this.speed = 0;
//   this.topSpeed = topSpeed || 50;
// }

// Vehicle.prototype.accelerate = function(increase) {
//   increase = increase || 10;
//   console.log("Accelerating!");
//   var newSpeed = this.speed + increase;

//   if (newSpeed > this.topSpeed) {
//     this.speed = topSpeed;
//   } else {
//     this.speed = newSpeed;
//   }

//   this.logSpeed();
// };

// Vehicle.prototype.logSpeed = function() {
//   console.log("Current Speed: " + this.speed);
// };

// Vehicle.prototype.brake = function() {
//   console.log("Hitting the brakes!");
//   this.speed = 0;
//   this.logSpeed();
// };

// var vehicle = new Vehicle();

// vehicle.logSpeed();

// vehicle.accelerate();

// vehicle.accelerate(30);

module.exports = Vehicle;
