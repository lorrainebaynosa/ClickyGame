// ROC: ES6 classes; objects inheriting other objects; javascript: parent object === prototype since it's the 1st object
// classes look like constructor functions but now we're using ES6 using classes; but it's just objects inheriting other objects

const Vehicle = require("./Vehicle");

// ROC: Car is Child of parent Vehicle class; Car inherits properties from Vehicle and so has access to every method Vehicle has
// "super" allows us to access data from object ("class") from which car is inheriting data (in this case, Vehicle)

class Car extends Vehicle {
  constructor(model, topSpeed) {
    super(topSpeed);
    this.model = model;
  }

  logSpeed() {
    console.log(`${this.model} is going ${this.speed}`);
  }
}
// REVIEW OF CONCEPTS:
// 1. In logSpeed(), this refers to the car model and not the Vehicle in Vehicle.js
// 2. TEMPLATE LITERALS: 
// (`${this.model} is going ${this.speed}`) is a template literal: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals: 
// a. enclosed by the back-tick (` `)  (grave accent) character instead of double or single quotes. STILL A STRING
// b. can contain placeholders - indicated by the dollar sign and curly braces (${expression}). The expressions in the placeholders and the text between the back-ticks (` `) get passed to a function. The default function just concatenates the parts into a single string. If there is an expression preceding the template literal (tag here), this is called a "tagged template". In that case, the tag expression (usually a function) gets called with the template literal, which you can then manipulate before outputting. To escape a back-tick in a template literal, put a backslash \ before the back-tick.
// https://codeburst.io/javascript-what-are-template-literals-5d08a50ef2e3
// c. easiest way to improve your JavaScript code readability when working with Strings. 
// when working with template literals, all you have to do to add a variable in is use the dollar sign followed by curly brackets: ${variableGoesHere}: 
// EXAMPLE: TEMPLATE LITERALS: console.log(`Hi, I'm ${p.name}! Call me "${p.nn}".`);
// d. LINE BREAKS w/TEMPLATE LITERALS: 
// WANT TO LOG: 
// Dear Mom,
// Hope you are well.
//     Love, your son
// // STRING CONCATENATION
// console.log("Dear Mom,\n" + 
// "Hope you are well.\n" + 
// "\tLove, your son")
// VS w/TEMPLATE LITERALS: type our text as we want it to appear since all new line characters, tabs, spaces, etc. inserted in the source become a part of the string.
// console.log(`Dear Mom,
// Hope you are well.
//     Love, your son`);
// That’s because, with template literals, 


const ferarri = new Car("Ferrari", 200);

ferarri.logSpeed();
ferarri.accelerate();
ferarri.accelerate(50);
ferarri.brake();

// function Car(model, topSpeed) {
//   Vehicle.call(this, topSpeed);
//   this.model = model;
// }

// Car.prototype = Object.create(Vehicle.prototype);

// Car.prototype.logSpeed = function() {
//   console.log(this.model + " is going " + this.speed);
// };

// var ferarri = new Car("Ferrari", 200);

// ferarri.logSpeed();
// ferarri.accelerate();
// ferarri.accelerate(50);
// ferarri.brake();

// ROC: when running/testing Car.js, comment out lines 25 and on since in Vehicle.js since we're requiring this file in Car.js and so will run all the code if not commmented out