// ROC: higher order functions do same thing but in fewer lines of code; any higher order function always takes a callback function
const moviePatrons = [
  { name: "Tom", age: 16 },
  { name: "Ashley", age: 31 },
  { name: "Sarah", age: 18 },
  { name: "Alvin", age: 22 },
  { name: "Cherie", age: 14 },
  { name: "Malcolm", age: 15 }
];

// 1. forEach

// forEach is a functional way of iterating through an array without a for-loop
// REVIEW OF CONCEPTS
// 1. forEach is an array method: only for arrays (not - objects)
// 2. for loop is agnostic 
// 

moviePatrons.forEach(patron => console.log("Patron age: " + patron.age));
moviePatrons.forEach(patron => {
  console.log("Patron: " + patron);
  console.log("Patron name: " + patron.name);
  console.log("Patron age: " + patron.age);
});
// REVIEW OF CONCEPTS, forEach METHOD:
// https://www.youtube.com/watch?v=rRgD1yVwIvE&t=951s
// 1. forEach: better way of iterating through/looping through an array than for loop
// 2. [name of array].forEach(function(){
  //  callback function code here;
// });
// 3. forEach takes in a callback function that can take in (3) different parameters (iterator/whatever is in the array, index, array) or can select one of them (usually the representation of the array); SYNCHRONOUS
// can also say moviePatrons.forEach(element => console.log(element.age)); can name element whatever you want; this is implicitly defined in forEach method


// 2. FILTER

// Filter returns a new array containing only elements whose callback returns a truthy value 

const canWatchRatedR = moviePatrons.filter(function(patron) {
  return patron.age >=17;
});
console.log("canWatchRatedR: " + canWatchRatedR);

// REVIEW OF CONCEPTS: use of an explicit return (vs IMPLICIT return):
const canWatchRatedRImplicit = moviePatrons.filter(patron => patron.age >=17);
console.log("canWatchRatedRImplicit" + canWatchRatedRImplicit);

// alternatively, can use a conditional to filter
const canWatchRatedRConditional = moviePatrons.filter(patron => {
  if (patron.age >=17) {
    return true;
  }
});
console.log("canWatchRatedRConditional" + canWatchRatedRConditional);


//  REVIEW OF CONCEPTS, FILTER method
// 1. filter is an array methods: only for arrays
// 2. If an arrow function only has one parameter, we can omit the parens () around the single parameter
// 3. EXPLICIT return is when you explicitly write the word return in the function.To do an IMPLICIT return, remove the word return, then move what you are returning up to the same line as the rest of the function. You can remove the curly brackets.
// 4. like forEach method, filter() takes in a callback function that can take in (3) different parameters (iterator/whatever is in the array, index, array) or can select one of them (usually the representation of the array); 
// 5. As with MAP method, assign result of filter method to a CONSTANT VARIABLE.


// 3. MAP (15:47, Traversy Media Video)

// REVIEW OF CONCEPTS, MAP METHOD
// 1. Map returns a brand new array the same length as the first. Each element is passed into the callback.
// 2. Whatever is returned from the callback at each iteration is what goes into that index of the new array
// 3. As with FILTER method, assign result of map method to a CONSTANT VARIABLE.
// 4. https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map: Since map builds a new array, using it when you aren't using the returned array is an anti-pattern; use forEach or for-of instead. Signs you shouldn't be using map: A) You're not using the array it returns, and/or B) You're not returning a value from the callback.

const cardedMoviePatrons = moviePatrons.map(patron => {
  if (patron.age >= 17) {
    patron.canWatchRatedR = true;
  } else {
    patron.canWatchRatedR = false;
  }
  return patron;
});

console.log("Carded Movie Patrons: " + cardedMoviePatrons);
console.log(cardedMoviePatrons);

// REVIEW OF CONCEPTS (test in node.js): ensure in same directory as index.js in terminal/bash: 
// node index.js
// returns:
// Patron age: 16
// Patron age: 31
// Patron age: 18
// Patron age: 22
// Patron age: 14
// Patron age: 15
// Patron: [object Object]
// Patron name: Tom
// Patron age: 16
// Patron: [object Object]
// Patron name: Ashley
// Patron age: 31
// Patron: [object Object]
// Patron name: Sarah
// Patron age: 18
// Patron: [object Object]
// Patron name: Alvin
// Patron age: 22
// Patron: [object Object]
// Patron name: Cherie
// Patron age: 14
// Patron: [object Object]
// Patron name: Malcolm
// Patron age: 15
// canWatchRatedR: [object Object],[object Object],[object Object]
// canWatchRatedRImplicit[object Object],[object Object],[object Object]
// canWatchRatedRConditional[object Object],[object Object],[object Object]
// Carded Movie Patrons: [object Object],[object Object],[object Object],[object Object],[object Object],[object Object]
// [ { name: 'Tom', age: 16, canWatchRatedR: false },
//   { name: 'Ashley', age: 31, canWatchRatedR: true },
//   { name: 'Sarah', age: 18, canWatchRatedR: true },
//   { name: 'Alvin', age: 22, canWatchRatedR: true },
//   { name: 'Cherie', age: 14, canWatchRatedR: false },
//   { name: 'Malcolm', age: 15, canWatchRatedR: false } ]
