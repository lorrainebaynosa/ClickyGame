import React from "react";
import Alert from "./components/Alert";

function App() {
  return <Alert type="danger">Invalid user id or password</Alert>;
}

export default App;

// REVIEW OF CONCEPTS: 
// Invalid user id or password: This is a child of Alert component because it's nested within Alert (parent) === {props.children} from Alert.js
// type="danger" is similar to a data attribute
// props ARE all objects
// VERIFY ON CONSOLE in dev tools: will see type and children
// here we pass in component Alert into component App