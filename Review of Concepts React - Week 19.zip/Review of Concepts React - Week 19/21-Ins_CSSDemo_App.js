import React from "react";
import Navbar from "./components/Navbar";
import Header from "./components/Header";
import Card from "./components/Card";

function App() {
  return (
    <div>
      <Header />
      <Navbar />
      <Card />
      <Card />
      <Card />
    </div>
  );
}

export default App;

// ROC: 
// 1. Where header, navbar, and card are components; 
// 2. <Header />: component in JSX syntax
// 3. App.js calls components that are to be used - DOES NOT define them. This notes the structure/layout to be displayed. The js files for components DEFINE components
// 4. We return <Card /> 3x because it renders 3x consecutively.
