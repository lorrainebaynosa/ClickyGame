import React from "react";

function HelloReact() {
  return <p>Hello World!</p>;
}

export default HelloReact;


// REVIEW OF CONCEPTS:
// import React from "react"; Whenever we use JSX inside of our JavaScript, we need to import the React library.  
// 1. The `HelloReact` function returns some JSX describing the UI we eventually want this particular component to be able to render to the document. If we were to change the JSX being returned by this function, and we were running our React app in dev mode (when we run `npm start`), the document would auto update inside of our web browser without us having to refresh. Create React App uses a Webpack development server that auto updates the view as the content changes.
// 2. https://reactjs.org/docs/introducing-jsx.html: 
// JSX: a syntax extension to JavaScript; recommended for use with React to describe what the UI should look like; produces React “elements”; also allows React to show more useful error and warning messages. Instead of artificially separating technologies by putting markup and logic in separate files, React separates concerns with loosely coupled units called “components” that contain both. 
// There should only be only one (1) COMPONENT in source folder
// What's happening inside of `src/components/HelloReact.js`? How does it relate to the content being rendered to the browser? 
// 1. importing reactLibrary to create React elements
// to have multiple elements render, you must wrap in a wrapper div; can't run
// function HelloReact() {
//   return <p>Hello World!</p>;
//   <p>hello Saturday!</p>
// }
// but can run 
// function HelloReact() {
//   //   return (
//     <div>
//       <p>Hello World!</p>;
//   //   <p>hello Saturday!</p>
//   </div>
  // )}

 