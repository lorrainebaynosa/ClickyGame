import React from "react";

const name = "Ahmed";
const num1 = 1;
const num2 = 2;

function JSXVariables() {
  return (
    <div className="main-container">
      <div className="container">
        <div className="jumbotron">
          {/* JavaScript expressions can be escaped inside of curly braces */}
          <h2>My name is {name}. But you can call me...</h2>
          <h1>The JSX Boss!</h1>
          <hr />
          <h2>I can do math: {num1 + num2}.</h2>
          <h2>
            I can generate random numbers:
            {Math.floor(Math.random() * 10) + 1},{Math.floor(Math.random() * 10) + 1},
            {Math.floor(Math.random() * 10) + 1}.
          </h2>
          <h2>I can even reverse my name: {name.split("").reverse()}</h2>
        </div>
      </div>
    </div>
  );
}

export default JSXVariables;

// REVIEW OF CONCEPTS: 
// What gets rendered is the resolution/result of the JavaScript expression
// heavy processing is done in controller; model and helpers define what
// we export JSXVariables after it has been resolved
// 1. https://reactjs.org/docs/introducing-jsx.html: 
// 2. EMBEDDING JAVASCRIPT EXPRESSIONS IN JSX: 
// 3. In the example above, we declare a variables called name, num1, and num2; then use it inside JSX by wrapping it in curly braces (can put any valid JavaScript expression inside the curly braces in JSX. For example, 2 + 2, user.firstName, or formatName(user) are all valid JavaScript expressions).
// 4. <h2>My name is {name}. But you can call me...</h2> is a React "element".
// 5. After compilation, JSX expressions become regular JavaScript function calls and evaluate to JavaScript objects (can use JSX inside of if statements and for loops, assign it to variables, accept it as arguments, and return it from functions).
// 6. Specifying Attributes with JSX: 
// Don’t put quotes around curly braces when embedding a JavaScript expression in an attribute (either use quotes (for string values) or curly braces (for expressions), but not both in the same attribute)
// 7. Since JSX is closer to JavaScript than to HTML, React DOM uses camelCase property naming convention instead of HTML attribute names (e.g., class becomes className in JSX, and tabindex becomes tabIndex).
// SPECIFYING CHILDREN WITHIN JSX: 
// 1. If a tag is empty, you may close it immediately with />, like XML:
// const element = <img src={user.avatarUrl} />;
// 2. JSX tags may contain children:
// const element = (
//   <div>
//     <h1>Hello!</h1>
//     <h2>Good to see you here.</h2>
//   </div>
// );
// Parent, children, and sibling relationships: https://www.w3schools.com/js/js_htmldom_navigation.asp

// JSX Prevents Injection Attacks:
// 1. safe to embed user input in JSX
// 2. By default, React DOM escapes any values embedded in JSX before rendering them. Thus it ensures that you can never inject anything that’s not explicitly written in your application. Everything is converted to a string before being rendered. This helps prevent XSS (cross-site-scripting) attacks.

// https://stackoverflow.com/questions/7381974/which-characters-need-to-be-escaped-in-html
// If you're inserting text content in your document in a location where text content is expected, you typically only need to escape the same characters as you would in XML. Inside of an element, this just includes the entity escape ampersand & and the element delimiter less-than and greater-than signs < >:

// & becomes &amp;
// < becomes &lt;
// > becomes &gt;
// Inside of attribute values you must also escape the quote character you're using:

// " becomes &quot;
// ' becomes &#39;

// JSX REPRESENTS OBJECTS
// Babel compiles JSX down to React.createElement() calls.

// These two examples are identical:

// const element = (
//   <h1 className="greeting">
//     Hello, world!
//   </h1>
// );
// const element = React.createElement(
//   'h1',
//   {className: 'greeting'},
//   'Hello, world!'
// );
// React.createElement() performs a few checks to help you write bug-free code but essentially it CREATES AN OBJECT LIKE THIS: 

// // Note: this structure is simplified
// const element = {
//   type: 'h1',
//   props: {
//     className: 'greeting',
//     children: 'Hello, world!'
//   }
// };
// These objects are called “React elements” (smallest building blocks of React Apps) - descriptions of what you want to see on the screen. React reads these objects and uses them to construct the DOM and keep it up to date. Unlike browser DOM elements, React elements are plain objects. React DOM takes care of updating the DOM to match the React elements. Elements != components but are part of components

// https://reactjs.org/docs/rendering-elements.html
// UPDATING RENDERED ELEMENT:
// React elements are immutable. Once you create an element, you can’t change its children or attributes. An element is like a single frame in a movie: it represents the UI at a certain point in time.only way to update the UI is to create a new element, and pass it to ReactDOM.render(). In practice, most React apps only call ReactDOM.render() once. 

// REACT ONLY updates What's Necessary:
// React DOM compares the element and its children to the previous one, and only applies the DOM updates necessary to bring the DOM to the desired state. Only the ELEMENT NODE whose contents has changed gets updated by REACT DOM (verify in Chrome Dev Tools, Elements, Console)

// https://reactjs.org/docs/components-and-props.html
// COMPONENTS & PROPS:
// COMPONENTS (FUNCTION VS CLASS COMPONENTS)
// 1. split UI into independent, reusable pieces, and think about each piece in isolation.
// 2. Always start component names with a capital letter. React treats components starting with lowercase letters as DOM tags. For example, <div /> represents an HTML div tag, but <Welcome /> represents a component and requires Welcome to be in scope.
// 3. FUNCTION COMPONENTS: like JavaScript functions (accept arbitrary inputs (“props” OBJECT ARGUMENT WITH DATA which stands for properties) and return React elements describing what should appear on the screen).
// a. EXAMPLE: function Welcome(props) {
//   return <h1>Hello, {props.name}</h1>;
// }
// 4. CLASS COMPONENTS (ES6 class to define a component): This component is equivalent to Welcome Function Component above
// class Welcome extends React.Component {
//   render() {
//     return <h1>Hello, {this.props.name}</h1>;
//   }
// }
// 5. RENDERING A COMPONENT: 
// a. React elements can represent DOM tags (const element = <div />;) or user-defined components  (const element = <Welcome name="Sara" />;). When React sees an element representing a user-defined component, it passes JSX attributes to this component as a single object (“props”).
// b. function Welcome(props) {
//   return <h1>Hello, {props.name}</h1>;
// }

// const element = <Welcome name="Sara" />;
// ReactDOM.render(
//   element,
//   document.getElementById('root')
// // );
// c. interpretation of function Welcome(props): 
// 1. We call ReactDOM.render() with the <Welcome name="Sara" /> element.
// 2. React calls the Welcome component with {name: 'Sara'} as the props.
// 3. Welcome component returns a <h1>Hello, Sara</h1> element as the result.
// 4. React DOM efficiently updates the DOM to match <h1>Hello, Sara</h1>.

// 6. COMPOSING COMPONENTS: 
// a. Components can refer to other components in their output. A button, a form, a dialog, a screen: in React apps, are commonly expressed as components.
// b. App component that renders Welcome many times:

// function Welcome(props) {
//   return <h1>Hello, {props.name}</h1>;
// }

// function App() {
//   return (
//     <div>
//       <Welcome name="Sara" />
//       <Welcome name="Edite" />
//     </div>
//   );
// }

// ReactDOM.render(
//   <App />,
//   document.getElementById('root')
// );
// c. Good rule of thumb: if part of your UI is used several times (Button, Panel, Avatar), or is complex enough on its own (App, FeedStory, Comment), it is a good candidate to be a reusable component.

// PROPS are READ-ONLY
// 1. Whether a component is a function or a class, it must never modify its own props. Such functions are called “pure” because they do not attempt to change their inputs, and always return the same result for the same inputs.
// All React components must act like pure functions with respect to their props.
// 2. Application UIs are dynamic and change over time. "State" allows React components to change their output over time in response to user actions, network responses, and anything else, without violating this rule.

// https://reactjs.org/docs/state-and-lifecycle.html

// function Clock(props) {
//   return (
//     <div>
//       <h1>Hello, world!</h1>
//       <h2>It is {props.date.toLocaleTimeString()}.</h2>
//     </div>
//   );
// }

// // CONVERTING A FUNCTION COMPONENT INTO A CLASS COMPONENT (e.g., Clock Function Component)
// 1. Create an ES6 class, with the same name, that extends React.Component.
// 2. Add a single empty method to it called render().
// 3. Move the body of the function into the render() method.
// 4. Replace props with this.props in the render() body.
// 5. Delete the remaining empty function declaration.

// class Clock extends React.Component {
//   render() {
//     return (
//       <div>
//         <h1>Hello, world!</h1>
//         <h2>It is {this.props.date.toLocaleTimeString()}.</h2>
//       </div>
//     );
//   }

// The render method will be called each time an update happens, but as long as we render <Clock /> into the same DOM node, only a single instance of the Clock class will be used. 

// ADDING LOCAL STATE TO A CLASS COMPONENT: 
// WITHOUT LOCAL STATE
// class Clock extends React.Component {
//   render() {
//     return (
//       <div>
//         <h1>Hello, world!</h1>
//         <h2>It is {this.props.date.toLocaleTimeString()}.</h2>
//       </div>
//     );
//   }
// }

// function tick() {
//   ReactDOM.render(
//     <Clock date={new Date()} />,
//     document.getElementById('root')
//   );
// }

// setInterval(tick, 1000);

// AFTER LOCAL STATE (move date from props to state in three steps): 
// 1. Replace this.props.date with this.state.date in the render() method
// 2. Add a class constructor that assigns the initial this.state & pass props to the base constructor, super. Class components should always call the base constructor with props.
// 3. Remove date prop from the <Clock /> element in ReactDOM.render ()

// class Clock extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {date: new Date()};
//   }

//   render() {
//     return (
//       <div>
//         <h1>Hello, world!</h1>
//         <h2>It is {this.state.date.toLocaleTimeString()}.</h2>
//       </div>
//     );
//   }
// }

// ReactDOM.render(
//   <Clock />,
//   document.getElementById('root')
// );
// https://www.youtube.com/watch?v=DJtI3Pogd88
// STATE & PROPS make React dynamic, internally & externally, respectively.
// // STATE: understanding setState enables you to understand how virtual DOM works.
// 1. Can only use state with Class Component (extending Component object with Class) (e.g., class Users extends Component). Cannot use state with functional components (stateless) 4:25
// PROPS
// 1. to get property, use {props.property} vs to get text, use {props.children}: 3:47