import React from "react";
import HelloBootstrap from "./components/HelloBootstrap";

function App() {
  return <HelloBootstrap />;
}

export default App;

// RENDERING A COMPONENT: 
// a. React elements can represent DOM tags (const element = <div />;) or user-defined components  (const element = <Welcome name="Sara" />;). When React sees an element representing a user-defined component, it passes JSX attributes to this component as a single object (“props”).
// b. function Welcome(props) {
//   return <h1>Hello, {props.name}</h1>;
// }

// const element = <Welcome name="Sara" />;
// ReactDOM.render(
//   element,
//   document.getElementById('root')
// // );
// c. interpretation of function Welcome(props): 
// 1. We call ReactDOM.render() with the <App /> element.
// 2. React calls the HelloBootstrap component with props ???
// 3. HelloBootstrap component returns code from HelloBootstrap.js
// 4. React DOM efficiently updates the DOM to match HelloBootstrap.js.
