import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App />, document.getElementById("root"));

// REVIEW OF CONCEPTS (test this code by cd into Activity 23) & enter the following in terminal: 
// 1. create-react-app reactpractice
// 2. cd into reactpractice
//    a. In VS code, transfer src folder from original code into reactpractice (I've just renamed other App.js and Index.js so they wouldn't conflict)
// 3. npm start to run ReactApp
// 4. Renders (on localhost:3000): "Invalid user id or password", which is the {props.children} of the Alert component of type=danger:  <Alert type="danger">Invalid user id or password</Alert> from App.js
