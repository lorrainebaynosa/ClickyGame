import React from "react";

// By extending the React.Component class, Counter inherits functionality from it
// ROC: https://reactjs.org/tutorial/tutorial.html?no-cache=1
// 1. React has a few different kinds of components. React.Component subclasses:
// components to tell React what we want to see on the screen. When our data changes, React will efficiently update and re-render our components.

// Counter is a React component class, or React component type. A component takes in parameters, called props (short for “properties”), and returns a hierarchy of views to display via the render method.

// The render method returns a description of what you want to see on the screen. React takes the description and displays the result. In particular, render returns a React element, which is a lightweight description of what to render. Most React developers use a special syntax called “JSX” which makes these structures easier to write. The <div /> syntax is transformed at build time to React.createElement('div'). 

class Counter extends React.Component {
  // Setting the initial state of the Counter component
  state = {
    count: 0
  };

  // ROC: handleIncrement increments this.state.count by 1
  // ROC: when Click btn, calls handleIncrement, state updates the count, this.state.count gets updated dynamically by virtual DOM: 
  handleIncrement = () => {
    // We always use the setState method to update a component's state
    this.setState({ count: this.state.count + 1 });
  };

  
  // The render method returns the JSX that should be rendered
  render() {
    return (
      <div className="card text-center">
        <div className="card-header bg-primary text-white">
          Click Counter!
        </div>
        <div className="card-body">
          <p className="card-text">Click Count: {this.state.count}</p>
          {/* https://reactjs.org/docs/state-and-lifecycle.html */}
          {/* IF NO STATE, would be {this.props.count} */}
          <button className="btn btn-primary" onClick={this.handleIncrement}>
            Increment
          </button>
        </div>
      </div>
    );
  }
}

export default Counter;

// REVIEW OF CONCEPTS:
// to have state, must use Class COMPONENTS (state-based component)
// extends React.Component gives us access to ReactComponent library
// https://reactjs.org/docs/state-and-lifecycle.html
// 1. State is similar to props, but it is private and fully controlled by the component.
// 2. The only place where you can assign this.state is the constructor.
// 3. Use setState() to re-render a component (schedule an update to a component’s state object). When state changes, the component responds by re-rendering.
// // Correct
// this.setState({comment: 'Hello'});
// 4. Neither parent nor child components can know if a certain component is stateful or stateless (thus, state is local/encapsulated: inaccessible to any component other than the ones that owns &sets it)
// 5. Any state is always owned by some specific component, and any data or UI derived from that state can only affect components “below” them in the tree: This is commonly called a “top-down” or “unidirectional” data flow.

// https://reactjs.org/docs/faq-state.html
// DIFFERENCE BETWEEN STATE & PROPS:
// 1. Props (short for “properties”) and state are both plain JavaScript objects. While both hold information that influences the output of render (props and state changes trigger a render update), they are different in one important way: props get passed to the component (similar to function parameters) whereas state is managed within the component (similar to variables declared within a function).

// 2. https://lucybain.com/blog/2016/react-state-vs-pros/: 
// PROPS: 
// 1. During a component’s life cycle props should not change (consider them immutable). Any React component that only uses props (and not state) as “pure,” that is, it will always render the same output given the same input; makes them really easy to test.
// 2. contains information set by the parent component (although defaults can be set).
// STATE: 
// 1. Like props, state holds information about the component. However, the kind of information and how it is handled is different. By default, a component has no state. 
// 2. When a component needs to keep track of information between renderings the component itself can create, update, and use state (e.g., how many times button is clicked)
// 3. is created in the component - where state gets it’s initial data. The inital data can be hard coded (as above), but it can also come from props.
// 4. is changeable: State is reserved only for interactivity, that is, data that changes over time.
// 5. contains “private” information for the component to initialise, change, and use on it’s own.

      // class Button extends React.Component {
      //   constructor() {
      //     super();
      //     this.state = {
      //       count: 0,
      //     };
      //   }

// state is created in the component - where state gets it’s initial data. The component is initialised and state.count is set to 0

      //   updateCount() {
      //     this.setState((prevState, props) => {
      //       return { count: prevState.count + 1 }
      //     });
      //   }

// change state to keep track of total number of clicks: setState 1) takes a function because setState can run asynchronously; 2) needs to take a callback function rather than updating the state directly - have access to prevState within the callback, this will contain the previous state, even if the state has already been updated somewhere else; 3) updates the state object and re-renders the component automagically.

      //   render() {
      //     return (<button
      //               onClick={() => this.updateCount()}
      //             >
      //               Clicked {this.state.count} times
      //             </button>);
      //   }
      // }

// onClick={() => this.updateCount()} means that when the button is clicked the updateCount method will be called. We need to use ES6’s arrow function so updateCount will have access to this instance’s state.

// The text rendered in the button is Clicked {this.state.count} times, which will use whatever this.state.count is at the time of rendering.

// FLOW OF CODE: 
// 1. The component is initialised and state.count is set to 0:

//   this.state = {
//     count: 0,
//   };

// 2. The component renders, with “Clicked 0 times” as the button text

//   Clicked {this.state.count} times

// 3. User clicks the button: click!

// 4. updateCount is called, bound to this instance of the component

// onClick={() => this.updateCount()}

// 5. updateCount calls setState with a call back to increase the counter from the previous state’s counter value

// updateCount() {
//   this.setState((prevState, props) => {
//     return { count: prevState.count + 1 }
//   });

// 6. setState triggers a call to render

// 7. The component renders, with “Clicked 1 times” as the button text

// Clicked {this.state.count} times


// HOW TO UPDATE STATE WITH VALUES THAT DEPEND ON CURRENT STATE: 
// 1. Pass an update function (updater) instead of an object to setState to ensure the call always uses the most updated version of state (see below). 
// 2. Example of code that will not behave as expected:
// incrementCount() {
//   // Note: this will *not* work as intended.
//   this.setState({count: this.state.count + 1});
// }

// handleSomething() {
//   // Let's say `this.state.count` starts at 0.
//   this.incrementCount();
//   this.incrementCount();
//   this.incrementCount();
//   // When React re-renders the component, `this.state.count` will be 1, but you expected 3.

//   // This is because `incrementCount()` function above reads from `this.state.count`,
//   // but React doesn't update `this.state.count` until the component is re-rendered.
//   // So `incrementCount()` ends up reading `this.state.count` as 0 every time, and sets it to 1.
// }

// 3. CODE THAT WILL BEHAVE AS EXPECTED (count of 3)
// incrementCount() {
//   this.setState((state) => {
//     // Important: read `state` instead of `this.state` when updating.
//     return {count: state.count + 1}
//   });
// }

// handleSomething() {
//   // Let's say `this.state.count` starts at 0.
//   this.incrementCount();
//   this.incrementCount();
//   this.incrementCount();

//   If you read `this.state.count` now, it would still be 0.
//   But when React re-renders the component, it will be 3.
// }

// React intentionally “waits” until all components call setState() in their event handlers before starting to re-render. This boosts performance by avoiding unnecessary re-renders.

// setState is asynchronous inside event handlers (ensures, for example, that if both Parent and Child call setState during a click event, Child isn’t re-rendered twice.)

// https://github.com/uberVU/react-guide/blob/master/props-vs-state.md
// Changing props and state
//                                               props	  state
// Can get initial value from parent Component?	 Yes	     Yes
// Can be changed by parent Component?         	 Yes	     No
// Can set default values inside Component?*	   Yes	     Yes
// Can change inside Component?	                 No	       Yes
// Can set initial value for child Components?	 Yes	     Yes
// Can change in child Components?	             Yes	     No