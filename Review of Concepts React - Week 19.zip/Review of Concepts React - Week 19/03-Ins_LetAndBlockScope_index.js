// ROC: 1) can scope within function context; variables have been scoped to function so far; 2) let allows us to block-scope with for loops and conditionals unless defined globally at the beginning of the code: where you define it, is where it will be used; 3) var does not care about block-scope

// 1. When using var, our counter exists after a for-loop is done

for (var i = 0; i < 5; i++) {
  console.log(i);
}

console.log("I: " + i); // Prints 5


// When using let, our counter is not defined outside of the for-loop block
// ROC: j is not available outside context of for loop because of let

// let x = 42;

// for (let j = 0; j < 5; j++) {
//   console.log(j);
//   console.log(x);
// }

// console.log(j); // ReferenceError: j is not defined

// let j = 42;
// console.log("J: " + j); // prints 42

// ==========================================================================

// 2. When using while loops, any values we create inside exist outside of the while-loop block
// ROC: The while loop loops through a block of code as long as a specified condition is true.

var count = 0;
// ROC var means count is available below; if tripled was a function, we couldn't access it outside of the fcn

while (count < 5) {
  var tripled = count * 3;
  count++;
}

console.log("Tripled: " + tripled); // Prints 12

// ==========================================================================

// 3. When using let, values defined inside of the while-loop block don't exist outside of it

// let c = 0;
// // ROC: c is available locally but quadrubled is only available in the while-loop

// while (c < 5) {
//   let quadrupled = c * 3;
//   c++;
// }

// console.log("Quadrupled: " + quadrupled); // ReferenceError: quadrupled is not defined

// ==========================================================================

// 4. When writing conditionals, values defined inside the conditional block exist outside of it

if (true) {
  var favoriteColor = "red";
}

console.log("favorite color: " + favoriteColor); // Prints `red`

// When using let, values defined inside of a conditional block don't exist outside

let favoriteFood;

if (true) {
  favoriteFood = "pizza";
}

// This works since favoriteFood is not defined inside of a block
console.log("favorite food: " + favoriteFood);
// Prints `pizza`

// REVIEW OF CONCEPTS (test in node.js): ensure in same directory as index.js in terminal/bash: 
// node index.js
// PRINTS: 
// 0
// 1
// 2
// 3
// 4
// I: 5
// Tripled: 12
// favorite color: red
// favorite food: pizza
