// * Open [Unsolved/index.html](Unsolved/index.html) in your web browser and take a moment to understand the application's functionality.

//   * This example is similar to the Crystal Guessing Game we worked on many weeks ago.

// * Now open [Unsolved/index.js](Unsolved/index.js) in your code editor and convert the existing code over to use the ES6 syntax we've learned about in the previous examples.

// * Make sure to do the following:

// 1. Convert all `var` identifiers to use `const` or `let` &mdash; whichever is more appropriate.

// 2. Convert functions to arrow functions **where suitable** &mdash; remember, arrow functions are not right for every situation.

// * **IMPORTANT**: After each change, run the the code in your web browser to make sure that everything still works as expected. If completed successfully, there should be no difference in the way the app runs in the browser before and after the changes.

// ### Hints

// * You don't need to understand how all of the code works in order to convert it over to the ES6 syntax we learned about.

// * Remember to use `let` where values are expected to be reassigned, use `const` for when they are not.

// * Remember that arrow functions can't be used as constructor functions, and they are not suitable for object methods.

const $root = document.querySelector("#root");

let score;
let targetScore;

const makeGuess = () => {
  const $score = document.querySelector("#root p");
  $score.textContent = "Score: " + score + " | " + "Target: " + targetScore;

  if (score > targetScore) {
    alert("You lost this round!");
    playRound();
  } else if (score === targetScore) {
    alert("You won this round!");
    playRound();
  }
};

// ROC
// 1. all functions are constants
// 2. arrow functions can't be used as constructor functions, and they are not suitable for object methods. 
// 3. Arrow functions bind the `this` keyword to the object it's created inside of; i.e. whatever `this` is where it's created; arrow function implicitly knows what "this" is; knows "this" refers to person object outside that function; arrow fcn will pass in the context of this from prior context so we can remove .bind(this) from code below
// 4. () means no parameters
// 5. REVIEW WITH ALEX/TUTOR: We don't make function expression Crystal an arrow function because it's not suitable for object methods. We remove .bind(this) because it's implicit in the callback function

const Crystal = function(color) {
  this.element = document.createElement("div");
  this.element.className = "crystal " + color;
  this.value = 0;

  this.element.addEventListener(
    "click",
    () => {
      score += this.value;
      makeGuess();
    },
    false
  );
};

// 5. REVIEW WITH ALEX/TUTOR: We don't make function expression Crystal an arrow function because it's not suitable for object methods. 

Crystal.prototype.render = function(target) {
  this.value = Math.floor(Math.random() * 15) + 1;
  target.appendChild(this.element);
};

const crystals = [new Crystal("red"), new Crystal("blue"), new Crystal("green")];

const playRound = () => {
  const fragment = document.createDocumentFragment();
  const $score = document.createElement("p");
  targetScore = Math.floor(Math.random() * 50) + 25;
  score = 0;
  $score.textContent = "Score: " + score + " | " + "Target: " + targetScore;
  crystals
    // .sort(function() {
    //   return 0.5 - Math.random();
    // })
    .sort(() => 0.5 - Math.random())
    // .forEach(function(crystal) {
    //   crystal.render(fragment);
    // });
    .forEach(crystal =>
      crystal.render(fragment));
  fragment.appendChild($score);
  $root.innerHTML = "";
  $root.appendChild(fragment);
};

playRound();
